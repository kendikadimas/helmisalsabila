var R=require("../../chunks/[turbopack]_runtime.js")("server/app/sitemap.xml/route.js")
R.c("server/chunks/[externals]__0lb_xtw._.js")
R.c("server/chunks/_1cl7h6e._.js")
R.c("server/chunks/[root-of-the-server]__20wgoou._.js")
R.c("server/chunks/_next-internal_server_app_sitemap_xml_route_actions_05l5km9.js")
R.m(83345)
module.exports=R.m(83345).exports
