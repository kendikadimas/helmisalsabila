globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/zlHdAFvoedjVub4KmiwOE/_buildManifest.js",
    "static/zlHdAFvoedjVub4KmiwOE/_ssgManifest.js",
    "static/zlHdAFvoedjVub4KmiwOE/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3s6nzrbk-8mnv.js",
    "static/chunks/19mx3mg6lkumu.js",
    "static/chunks/227kwhsrjlnp4.js",
    "static/chunks/18m0vqjfiycrb.js",
    "static/chunks/06z9j7lk94lr4.js",
    "static/chunks/turbopack-1e8snl5l4fyrr.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
